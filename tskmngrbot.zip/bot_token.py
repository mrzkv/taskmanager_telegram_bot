async def get_token():
    token = "7529552259:AAFOx8b5uOjsvLBT482HCtN6lWwv30dgVf8"
    return token